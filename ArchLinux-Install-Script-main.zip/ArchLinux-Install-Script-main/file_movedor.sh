mv ./file_movido.sh /mnt
